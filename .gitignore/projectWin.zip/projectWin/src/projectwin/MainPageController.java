/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectwin;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author dalyakhatun
 */


public class MainPageController implements Initializable {
    @FXML Button logoutButton; 
    
    @FXML Label test; 
    @FXML PieChart PieChart; 
    @FXML PieChart areaPieChart; 
    
    //menu bar buttons 
    @FXML Button homeMenuB; 
    @FXML Button registrationMenuB; 
    @FXML Button studentRecordsMB; 
    @FXML Button studentAccountMB; 
    @FXML Button financialAidMB; 
    @FXML Button personalInfoMB; 
    @FXML TextField campus_Id; 
     
  //  String loggedStudent; 
    // go to MenuRegistration 
    @FXML
    private void registrationMenuBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) registrationMenuB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("MenuRegistration.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML
    private void homeMenuBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) homeMenuB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML
    private void studentRecordsMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) studentRecordsMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("studentRecordsPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void studentAccountMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) studentAccountMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("studentAccountsPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void financialAidMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) financialAidMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("financialAidPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void personalInfoMBAction(ActionEvent e) throws IOException{
        Stage stage; 
     Parent root;
 

      stage=(Stage) personalInfoMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("personalInfoPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML 
    private void logoutButtonAction (ActionEvent event) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) logoutButton.getScene().getWindow();
      //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
 
      //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show();         
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    campus_Id.setDisable(true);
    //get credit hours from the database 
    
    // credits pie chart 
    ObservableList<PieChart.Data> pieChartData=FXCollections.observableArrayList(
    new PieChart.Data("My Credit Hours", 30),
    new PieChart.Data("Remaining Credit Hours", 70)
    );
    PieChart.setData(pieChartData);  
    
    AreaPieChart(); 

    
    }    
    public void setText(String campus_Id) {
        this.campus_Id.setText(campus_Id);
    }

    private void AreaPieChart() {
        //    // area pie chart 
    ObservableList<PieChart.Data> AreaChartData=FXCollections.observableArrayList(
    new PieChart.Data("Area A", 'A'),
    new PieChart.Data("Area B", 'B'),
    new PieChart.Data("Area C", 'C'),
    new PieChart.Data("Area D", 'D'),
    new PieChart.Data("Area E", 'E'),
    new PieChart.Data("Area F", 'F')

    );
    areaPieChart.setData(AreaChartData); 
    }
     
}
