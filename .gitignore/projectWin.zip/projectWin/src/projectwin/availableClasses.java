
package projectwin;

import javafx.scene.control.CheckBox;


/**
 *
 * @author dalyakhatun
 */
public class availableClasses {
    //database  columns
    private  CheckBox selectdb;
    private  String crn;
    private  String subject;
    private  String course;
    private  String credit;
    private  String title;
    private  String timedb;
    private  String instructor;
    private  String locationdb;
   
    // constructor 
    public availableClasses(String crn, String subject, String course, String credit, String title, String timedb, String instructor, String locationdb) {
        super(); 
        this.selectdb = new CheckBox();
        this.crn = crn;
        this.subject = subject;
        this.course = course;
        this.credit = credit;
        this.title = title;
        this.timedb = timedb;
        this.instructor = instructor;
        this.locationdb = locationdb;
    }

    public CheckBox getSelectdb() {
        return selectdb;
    }

    public String getCrn() {
        return crn;
    }

    public String getSubject() {
        return subject;
    }

    public String getCourse() {
        return course;
    }

    public String getCredit() {
        return credit;
    }

    public String getTitle() {
        return title;
    }

    public String getTimedb() {
        return timedb;
    }

    public String getInstructor() {
        return instructor;
    }

    public String getLocationdb() {
        return locationdb;
    }
    
    // setter 
    public void setSelectdb(CheckBox selectdb) {
        this.selectdb = selectdb;
    }

    public void setCrn(String crn) {
        this.crn = crn;
    }

    public void setSubject(String subject) {
        this.subject = subject;
        }

    public void setCourse(String course) {
        this.course = course;
        }

    public void setCredit(String credit) {
        this.credit = credit;
        }

    public void setTitle(String title) {
        this.title = title;
        }

    public void setTimedb(String timedb) {
        this.timedb = timedb;
       }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
        }

    public void setLocationdb(String locationdb) {
        this.locationdb = locationdb;                       
    }
    
} 
