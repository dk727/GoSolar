/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectwin;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author dalyakhatun
 */
public class RegistrationController implements Initializable {

    
    @FXML Button  backButton; 
    @FXML TextField firstName; 
    @FXML TextField lastName; 
    @FXML TextField campusID;
    @FXML PasswordField password; 
    @FXML Button registerButton; 
    @FXML Label warning; 
    
    
    
    @FXML 
    private void registerButtonAction (ActionEvent event) throws IOException {
        String fn= firstName.getText(); 
        String ln= lastName.getText(); 
        String id= campusID.getText(); 
        String pas = password.getText(); 
        
              
        Connection con;
            try {
                con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "Dalya1234");
            PreparedStatement statement = (PreparedStatement) con.prepareStatement("insert into registrationdata(firstname, lastname, campusid, pass) values (?,?,?,?)");
					statement.setString(1, fn );
					statement.setString(2, ln);
					statement.setString(3, id);
					statement.setString(4, pas);
					
					statement.execute();
                                        goToLoginPage();

            } catch (SQLException ex) {
                System.out.print("failed"); 
            }
        
    }

    @FXML 
    private void backButtonAction (ActionEvent event ) throws IOException{
     Stage stage; 
     Parent root;
 
          
      stage=(Stage) backButton.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    

    private void goToLoginPage() throws IOException {
          Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Registration");
                    alert.setHeaderText(null);
                    alert.setContentText("Registration Successful!");

                    alert.showAndWait();
    Stage stage; 
    Parent root;
 
      stage=(Stage) registerButton.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 

    }
    
}
