/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectwin;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author dalyakhatun
 */
public class SearchClassesController implements Initializable {

    @FXML Button logoutButton; 
    //menu bar buttons 
    @FXML Button homeMenuB; 
    @FXML Button registrationMenuB; 
    @FXML Button studentRecordsMB; 
    @FXML Button studentAccountMB; 
    @FXML Button financialAidMB; 
    @FXML Button personalInfoMB; 
    @FXML TextField campus_Id_fordb; 
    @FXML Button AddButton; 
    
    
   // table setup 
    @FXML TableView <availableClasses> table; 
    // column setup 
    @FXML private TableColumn < ?, ?> selectCol; 
    @FXML private TableColumn < ?, ?> crnCol; 
    @FXML private TableColumn < ?, ?> subjectCol; 
    @FXML private TableColumn < ?, ?> courseCol; 
    @FXML private TableColumn < ?, ?> creditCol; 
    @FXML private TableColumn < ?, ?> titleCol; 
    @FXML private TableColumn < ?, ?> timeCol; 
    @FXML private TableColumn < ?, ?> instructorCol; 
    @FXML private TableColumn < ?, ?> locationCol; 
        
   
  //  private IntegerProperty index= new SimpleIntegerProperty(); 
    
    @FXML 
    private void AddButtonAction(ActionEvent event){
         availableClasses selrow = table.getSelectionModel().getSelectedItem();
         String my_campusid= campus_Id_fordb.getText();
         String my_crn= selrow.getCrn();
         String my_subjectCol= selrow.getSubject();
         String my_course= selrow.getCourse(); 
         String my_credit=selrow.getCredit(); 
         String my_titlecol= selrow.getTitle();
         String my_timedb=selrow.getTimedb();
         String my_instructorCol= selrow.getInstructor(); 
         String my_locationCol = selrow.getLocationdb();
         insertData(selrow,my_campusid,my_crn, my_subjectCol,my_course,my_credit,my_titlecol,my_timedb,my_instructorCol,my_locationCol);
        //add selected row to myClasses table 
 
    }
    // go to MenuRegistration 
    @FXML
    private void registrationMenuBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) registrationMenuB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("MenuRegistration.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML
    private void homeMenuBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) homeMenuB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML
    private void studentRecordsMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) studentRecordsMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("studentRecordsPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void studentAccountMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) studentAccountMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("studentAccountsPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void financialAidMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) financialAidMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("financialAidPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void personalInfoMBAction(ActionEvent e) throws IOException{
        Stage stage; 
     Parent root;
 

      stage=(Stage) personalInfoMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("personalInfoPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 
    }
      
    
    @FXML 
    private void logoutButtonAction (ActionEvent event) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) logoutButton.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show(); 
        
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     //   campus_Id.setDisable(true);
     //   campus_Id_fordb.setPromptText("CampusID");
        loadData();

    }    
    
    private void loadData() {
        
    try {
            //
            //database coonection
            Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "Dalya1234");
            ObservableList<availableClasses> data= FXCollections.observableArrayList();
            selectCol.setCellValueFactory(new PropertyValueFactory<>("selectdb"));
            crnCol.setCellValueFactory(new PropertyValueFactory<>("crn"));
            subjectCol.setCellValueFactory(new PropertyValueFactory<>("subject"));
            courseCol.setCellValueFactory(new PropertyValueFactory<>("course"));
            creditCol.setCellValueFactory(new PropertyValueFactory<>("credit"));
            titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
            timeCol.setCellValueFactory(new PropertyValueFactory<>("timedb"));
            instructorCol.setCellValueFactory(new PropertyValueFactory<>("instructor"));
            locationCol.setCellValueFactory(new PropertyValueFactory<>("locationdb"));
            String sql = "select * from allclasses"; 
            PreparedStatement preparedStatement = con.prepareStatement(sql); 
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                data.add(new availableClasses(
                rs.getString("crn"),
                rs.getString("subject"),
                rs.getString("course"),
                rs.getString("credit"),
                rs.getString("title"),
                rs.getString("timedb"),
                rs.getString("instructor"),
                rs.getString("locationdb")
              
                ));
                table.setItems(data);


                }
                
                preparedStatement.close();
                rs.close();

            
        } catch (SQLException ex) {
            Logger.getLogger(SearchClassesController.class.getName()).log(Level.SEVERE, null, ex);
        }  
    }

    private void insertData(availableClasses selrow, String my_campusid, String my_crn, String my_subjectCol, String my_course, String my_credit, String my_titlecol, String my_timedb, String my_instructorCol, String my_locationCol) {

    try {
          Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "Dalya1234");
            PreparedStatement statement = (PreparedStatement) con.prepareStatement("insert into myclasses (campusid, crn, subject, course, credit, title, timedb, instructor, locationdb) values (?,?,?,?,?,?,?,?,?)");
					statement.setString(1, my_campusid );
					statement.setString(2, my_crn);
					statement.setString(3, my_subjectCol);
					statement.setString(4, my_course);
                                        statement.setString(5, my_credit );
					statement.setString(6, my_titlecol);
					statement.setString(7, my_timedb);
					statement.setString(8, my_instructorCol);
					statement.setString(9, my_locationCol);
					
					statement.execute();
                                        yourClassisAdded();  
                                       
            } catch (SQLException ex) {
                
                System.out.print("failed"); 
                System.err.println("Caught IOException: " + ex.getMessage());

            }    

    }

    private void yourClassisAdded() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Successful");
                    alert.setHeaderText(null);
                    alert.setContentText("Your class is added!");

                    alert.showAndWait();

    }
   
}


