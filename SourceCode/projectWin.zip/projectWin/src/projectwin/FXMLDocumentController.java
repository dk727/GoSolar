/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectwin;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author dalyakhatun
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
      
    
    @FXML TextField campus_Id; 
    @FXML PasswordField password; 
    @FXML Button registerButton; 
    @FXML Button loginButton; 
    
    
    @FXML
    private void registerAction(ActionEvent event) throws IOException {
     Stage stage; 
     Parent root;
 
          
      stage=(Stage) registerButton.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("FXMLRegistration.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }
    @FXML 
    private void loginButtonAction (ActionEvent event) throws IOException, SQLException{
      String InputId= campus_Id.getText(); 
      String InputPass = password.getText();    
      Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "Dalya1234");
      String sql = "SELECT * FROM registrationdata WHERE campusid = ? AND pass = ?";

        PreparedStatement preparedStatement = con.prepareStatement(sql);
        preparedStatement.setString(1, InputId);
        preparedStatement.setString(2, InputPass);

        Statement s = con.createStatement();
        ResultSet rs = preparedStatement.executeQuery();

        ////if there are next ib rs so you have a user by this id and password 
        if(rs.next()) {
    //    loginSuccessful();  
        Stage stage; 
        Parent root;
        FXMLLoader Loader = new FXMLLoader();     
        Loader.setLocation(getClass().getResource("mainPage.fxml"));
        Loader.load(); 
        MainPageController display = Loader.getController(); 
        display.setText(InputId);
        Parent p = Loader.getRoot(); 
        stage=(Stage) loginButton.getScene().getWindow();
        stage.setScene(new Scene (p));
        stage.showAndWait(); 
        }
        else {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Invalid Login Information");
        alert.setHeaderText(null);
        alert.setContentText("Please verify your campus ID and password!");
        alert.showAndWait();

        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

//    private void loginSuccessful() throws IOException {
//        
//     Stage stage; 
//     Parent root;
// 
//      stage=(Stage) loginButton.getScene().getWindow();
//        //load up OTHER FXML document
//      root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
// 
//     //create a new scene with root and set the stage
//    
//      Scene scene = new Scene(root);
//      stage.setScene(scene);
//      stage.show();
//       
//    }

  

   
    
}


