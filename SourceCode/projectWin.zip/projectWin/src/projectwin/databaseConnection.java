/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectwin;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author dalyakhatun
 */
public class databaseConnection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    try{
        Class.forName("org.postgresql.Driver"); 
    } 
    catch (Exception e) {
        System.out.print("Failed to load the JDBC driver"); 
    }

    try{
        Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "Dalya1234");
        System.out.print("Connected"); 

    } 
    catch (Exception e) {
        System.out.print("JDBC driver is not connected"); 
    }
    }
    
}
